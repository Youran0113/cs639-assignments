This is CS639 HW1 written by Youran Wang.
I used pretrained embedding GloVE called glove.2024.wikigiga.300d.txt

Link: https://nlp.stanford.edu/data/glove.2024.wikigiga.300d.zip